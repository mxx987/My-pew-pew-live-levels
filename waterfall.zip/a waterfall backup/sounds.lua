sounds = {
  {
    frequency = 696,
    decay = 0.36,
    waveform = "triangle",
  }
}