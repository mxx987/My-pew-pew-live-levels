meshes = {
  {
    vertexes = {{-20, 0}, {20, 0},{0, -20}, {0, 20}},
    colors = {0x00ffffff, 0x00ffffff, 0x00ffffff, 0x00ffffff},
    segments = {{0, 1},{2, 3}}
  }
}